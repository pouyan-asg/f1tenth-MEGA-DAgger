"""
The objective of this code is to simulate and visualize lane switching behavior for autonomous racing agents in the F1Tenth Gym environment:

It sets up lane switcher planners for ego and opponent cars.
Runs multiple simulation episodes with randomized starting positions.
Executes planning and control for both agents, including lane switching and collision handling.
Visualizes the simulation and tracks performance metrics.
In summary:
This code tests and visualizes lane switching strategies for autonomous racing agents in multi-agent simulation scenarios.
"""


import os
import json
import numpy as np
from argparse import Namespace

# Seed
seed = 6300
rng = np.random.default_rng(seed)
xy_noise_scale = 0.0
theta_noise_scale = 0.0


def random_position(waypoints_xytheta, sampled_number=1, rng=None, xy_noise=0.0, theta_noise=0.0):
    ego_idx = rng.choice(np.arange(0, len(waypoints_xytheta)), 1)[0]
    # ego_idx = 790
    print(f'ego_idx is {ego_idx}')
    for i in range(sampled_number):
        starting_idx = (ego_idx + i * 10) % len(waypoints_xytheta)
        x, y, theta = waypoints_xytheta[starting_idx][0], waypoints_xytheta[starting_idx][1], \
                      waypoints_xytheta[starting_idx][2]
        x = x + rng.random(size=1)[0] * xy_noise
        y = y + rng.random(size=1)[0] * xy_noise
        theta = (zero_2_2pi(theta) + 0.5 * np.pi) + rng.random(size=1)[0] * theta_noise
        if i == 0:
            res = np.array([[x, y, theta]])  # (1, 3)
        else:
            res = np.vstack((res, np.array([[x, y, theta]])))
    return res, ego_idx


# Set planner
from es.planner.lattice_planner import LatticePlanner
from es.planner.lane_switcher import LaneSwitcher
import gym
from es.utils.DataProcessor import RolloutDataLogger
from es.utils.utils import *
from es.utils.visualize import LatticePlannerRender, LaneSwitcherRender
from es.worker import calculate_objectives
import yaml

map_name = 'General1'
lane_switcher_conf_path = \
    os.path.join('..', 'configs', map_name, 'lane_switcher_config.yaml')
with open(lane_switcher_conf_path) as file:
    lane_switcher_conf_dict = yaml.load(file, Loader=yaml.FullLoader)
lane_switcher_conf = Namespace(**lane_switcher_conf_dict)

ego_planner = LaneSwitcher(conf=lane_switcher_conf)
opp_planner = LaneSwitcher(conf=lane_switcher_conf)
waypoints_xytheta = ego_planner.lane_xytheta[0]

env = gym.make('f110_gym:f110-v0', map=lane_switcher_conf.map_path, map_ext='.png', num_agents=2)
render = LaneSwitcherRender(ego_planner)
env.add_render_callback(render.render_callback)
render_sim = True

# Settings for simulating collision between ego vehicle and opponent vehicle
ego_oppo_collision_prob = 0.8 # Probability of collision between ego vehicle and opponent vehicle
collision_trigger_dist_thresh = 10 # Distance threshold for triggering collision


step_count = 0

for i in range(10):
    # Reset peer collision overwritten flag
    ego_planner.collision_traj_overwritten_flag = None
    opp_planner.collision_traj_overwritten_flag = None


    init_poses, _ = random_position(waypoints_xytheta, 2, rng, xy_noise_scale, theta_noise_scale)
    obs, _, done, _ = env.reset(init_poses)
    laptime = 0

    if render_sim:
        env.render('human')

    while not done and laptime < 8:
        oppo_pose = obsDict2oppoArray(obs, 0)
        ego_best_traj = ego_planner.plan(obs['poses_x'][0], obs['poses_y'][0], obs['poses_theta'][0], oppo_pose,
                                         obs['linear_vels_x'][0], ego_oppo_collision_prob, collision_trigger_dist_thresh, 1)

        ## oppo planner here
        oppo_pose = obsDict2oppoArray(obs, 1)
        opp_best_traj = opp_planner.plan(obs['poses_x'][1], obs['poses_y'][1], obs['poses_theta'][1], oppo_pose,
                                         obs['linear_vels_x'][1], ego_oppo_collision_prob, collision_trigger_dist_thresh, 0.0)
        tracker_count = 0

        while not done and tracker_count < lane_switcher_conf.tracker_steps:
            ego_steer, ego_speed = ego_planner.tracker.plan(obs['poses_x'][0], obs['poses_y'][0],
                                                            obs['poses_theta'][0],
                                                            obs['linear_vels_x'][0], ego_best_traj)
            ## oppo planner here
            opp_steer, opp_speed = opp_planner.tracker.plan(obs['poses_x'][1], obs['poses_y'][1],
                                                            obs['poses_theta'][1],
                                                            obs['linear_vels_x'][1], opp_best_traj)
            ## oppo planner here
            action = np.array([[ego_steer, ego_speed], [opp_steer, opp_speed*0.8]])
            obs, timestep, done, _ = env.step(action)

            step_count += 1

            # print(action)
            if np.any(obs['collisions']):
                done = True
            laptime += timestep
            tracker_count += 1
            if render_sim:
                env.render('human')
    print("finish one episode")

    print("total number of steps: ", step_count)
    step_count = 0
    print("=================================")


