""""
The objective of this code is to check safety using Control Barrier Functions (CBF) 
for autonomous racing agents.
This code provides functions to filter out unsafe actions or states by evaluating collision 
risk between vehicles and with track boundaries using CBF criteria.
"""


agentsThreshold = 0.65 # safe minimum distance between agents' centers
borderThreshold = 0.42 # safe maximum distance between agent and boundary
eta_agents = 0.9 # parameter for discrete CBF, it could vary from 0 to 1
eta_border = 0.9

def CBFagent(x_ego, y_ego, x_opp, y_opp, x_ego_next, y_ego_next, x_opp_next, y_opp_next):

    """
        Check collisions between agents using CBF:
        Checks if the ego vehicle and opponent vehicle are at a safe distance now and 
        in the next step, returning whether the situation is safe or unsafe.

        Args:
            x_ego: ego vehicle position x
            y_ego: ego vehicle position y
            x_opp: opponent vehicle position x
            y_opp: opponent vehicle position y
            x_ego_next: ego vehicle next position x
            y_ego_next: ego vehicle next position y
            x_opp_next: opponent vehicle next position x
            y_opp_next: opponent vehicle next position y

        Returns:
            True: safe
            False: unsafe

        TODO: write a more precise collision-checking CBF
    """

    currentCBFValue = (x_ego - x_opp) ** 2 + (y_ego - y_opp) ** 2 - agentsThreshold ** 2
    nextCBFValue = (x_ego_next - x_opp_next) ** 2 + (y_ego_next - y_opp_next) ** 2 - agentsThreshold ** 2
    sigma_t = nextCBFValue - currentCBFValue + eta_agents * currentCBFValue
    #print("CBF value: ", CBFvalue)
    if sigma_t >= - 0.1: # account for discretization error
        return True, sigma_t
    else:
        return False, sigma_t

def CBFborder(x_ego, y_ego, x_line, y_line, x_ego_next, y_ego_next, x_line_next, y_line_next):
    
    """
        Check collisions between agent and boundary using CBF:
        Checks if the ego vehicle is at a safe distance from the track boundary now and 
        in the next step, returning whether the situation is safe or unsafe.

        Args:
            x_ego: ego vehicle position x
            y_ego: ego vehicle position y
            x_line: nearest boundary (one-side) position x
            y_line: nearest boundary (one-side) vehicle position y
            x_ego_next: ego vehicle next position x
            y_ego_next: ego vehicle next position y
            x_line_next: nearest boundary (one-side) position x
            y_line_next: nearest boundary (one-side) position y

        Returns:
            True: safe
            False: unsafe

        TODO: write a more precise collision-checking CBF
    """
    
    currentCBFValue = (x_ego - x_line) ** 2 + (y_ego - y_line) ** 2 - borderThreshold ** 2
    nextCBFValue = (x_ego_next - x_line_next) ** 2 + (y_ego_next - y_line_next) ** 2 - borderThreshold ** 2
    sigma_t = nextCBFValue - currentCBFValue + eta_border * currentCBFValue
    # print("CBF border value: ", sigma_t)
    if sigma_t >= - 0.1: # account for discretization error
        return True, sigma_t
    else:
        return False, sigma_t
